---
name: Academic Clarity
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#434655'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#5a5f62'
  on-secondary: '#ffffff'
  secondary-container: '#dce0e4'
  on-secondary-container: '#5e6367'
  tertiary: '#005a82'
  on-tertiary: '#ffffff'
  tertiary-container: '#0074a6'
  on-tertiary-container: '#e4f2ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dfe3e7'
  secondary-fixed-dim: '#c3c7cb'
  on-secondary-fixed: '#171c1f'
  on-secondary-fixed-variant: '#43474b'
  tertiary-fixed: '#c9e6ff'
  tertiary-fixed-dim: '#89ceff'
  on-tertiary-fixed: '#001e2f'
  on-tertiary-fixed-variant: '#004c6e'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  h1:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h2:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  h3:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-max: 1440px
  gutter: 24px
  margin-page: 40px
  card-padding: 24px
---

## Brand & Style

The brand personality centers on **Intellectual Clarity** and **Institutional Trust**. This design system balances the rigorous tradition of academia with a forward-thinking, tech-enabled future. It aims to reduce the cognitive load of administrative tasks like course registration through a minimalist and elegant interface.

The visual style is a blend of **Modern Minimalism** and **Refined Glassmorphism**. By prioritizing white space and structural order, the system evokes a sense of calm and focus. Subtle translucency and soft layering provide a premium, multi-dimensional feel that distinguishes the platform from dated, utilitarian academic software.

## Colors

The palette is anchored in a high-ratio of white to create a "breathable" interface. 
- **Primary:** A refined Light Blue (#2563EB) used for primary actions, active states, and essential brand identifiers.
- **Secondary/Background:** A very soft Grey (#F1F5F9) is used for the main application background to separate the canvas from the content cards.
- **Surface:** Pure White (#FFFFFF) is reserved for cards and containers to ensure they "pop" against the soft background.
- **Accent:** A brighter Cyan-Blue (#0EA5E9) is used sparingly for informational badges and progress indicators.
- **Text:** Deep Navy-Grey (#1E293B) for high-contrast legibility, with a softer Slate (#64748B) for secondary metadata.

## Typography

This design system utilizes **Inter** for its entire typographic scale. Inter provides a neutral, systematic, and utilitarian aesthetic that excels in data-heavy environments like course lists and schedules.

Visual hierarchy is achieved through significant weight variation and subtle letter-spacing adjustments on larger headings. Body text is set with generous line-height to ensure readability during long sessions of course browsing. Labels and captions use medium to semi-bold weights to remain legible at smaller scales.

## Layout & Spacing

The layout follows a **Fixed-Fluid Hybrid Grid**. The main content area is constrained to a maximum width of 1440px to prevent excessive line lengths on ultra-wide monitors, while the inner layout uses a 12-column fluid system.

Spacing is based on a 4px baseline grid. 
- **Page Margins:** 40px for desktop to provide a premium, airy feel.
- **Section Spacing:** 48px to 64px to clearly delineate different modules (e.g., between the "Current Schedule" and "Course Discovery").
- **Component Padding:** Cards use a consistent 24px internal padding to maintain a clean, organized appearance.

## Elevation & Depth

This design system uses a combination of **Ambient Shadows** and **Glassmorphism** to create a sense of organized hierarchy.

1.  **Base Layer:** The application background (#F1F5F9).
2.  **Card Layer:** White surfaces with a "Soft-Focus" shadow (Blur: 20px, Y: 4px, Color: rgba(0,0,0, 0.04)).
3.  **Interactive Layer:** Navigation sidebars and floating action panels utilize a light glassmorphism effect—`backdrop-filter: blur(12px)` with a semi-transparent white background (`rgba(255, 255, 255, 0.7)`).
4.  **Overlay Layer:** Modals and dropdowns use a more pronounced shadow (Blur: 40px, Y: 12px, Color: rgba(0,0,0, 0.08)) to indicate temporary prominence.

Borders are kept minimal, using a 1px solid stroke in a light grey-blue to define boundaries without adding visual noise.

## Shapes

The shape language is defined by **modern, generous roundedness**.
- **Standard Cards & Containers:** Use a 16px (`rounded-xl`) radius to evoke a friendly, approachable academic environment.
- **Buttons & Inputs:** Use a 12px (`rounded-lg`) radius to maintain consistency with the cards while appearing more structured.
- **Tags & Status Badges:** Utilize a pill-shaped (full-round) geometry to differentiate them from interactive buttons.

This consistent use of soft corners eliminates the "harshness" often associated with legacy administrative software.

## Components

### Cards
Cards are the primary container. They must feature a subtle 1px border (#E2E8F0) and the "Soft-Focus" shadow. For specialized data, like a "Course Card," use a light blue vertical accent bar on the left edge to denote "Selected" or "Primary" status.

### Buttons
- **Primary:** Solid Light Blue with white text. No gradient, just a clean flat fill.
- **Secondary:** Ghost style with a 1px primary-colored border and light blue hover state.
- **Tertiary:** Text-only with an icon, used for low-priority actions like "View Details."

### Tables
Academic tables (for KRS lists) must be "borderless" in style. Use a light grey header row (#F8FAFC) with uppercase label-sm typography. Row separators should be 1px wide and very faint (#F1F5F9). Rows should have a subtle hover state that lifts the row slightly using a shadow.

### Form Inputs
Inputs use a 12px radius and a light grey background (#F8FAFC). Upon focus, the border transitions to Primary Blue with a soft blue outer glow (3px spread).

### Specialized Academic Components
- **Credit Counter (SKS):** A floating glassmorphic pill that tracks total credits in real-time.
- **Schedule Conflict Indicator:** A high-contrast red-tinted alert box with 12px rounding, placed within course selection cards.
- **Sidebar Navigation:** A slim, vertical glassmorphic bar on the left with minimalist line icons (2px stroke width).